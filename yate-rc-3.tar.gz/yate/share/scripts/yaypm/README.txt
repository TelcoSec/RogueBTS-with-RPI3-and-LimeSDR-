Instalation
===========
One needs:
Python 2.4(Python 2.5 is better as it allows to use inlineCallbacks), 
Twisted 2.x(http://twistedmatrix.com/projects/core/), and 
Zope 3.x(http://www.zope.org/Products/ZopeInterface) 
to use yaypm.

Then yaypm can be installed:
python setup.py install
